package org.example;

public class LibroFisico extends Libro{
    private Double costoEnvio;

    @Override
    public Double calcularPrecio() {

        return precioBase + costoEnvio;
    }

    public Double getCostoEnvio() {
        return costoEnvio;
    }

    public void setCostoEnvio(Double costoEnvio) {
        this.costoEnvio = costoEnvio;
    }
}
