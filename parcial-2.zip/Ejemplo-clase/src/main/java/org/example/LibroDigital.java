package org.example;

import java.io.Serializable;

public class LibroDigital extends Libro implements Serializable {
    private Double descuento;

    @Override
    public Double calcularPrecio() {
        return precioBase - descuento;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }
}
