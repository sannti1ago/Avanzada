package org.example;

import java.io.Serializable;

public abstract class Libro implements Serializable {
    protected int codigo;
    protected String titulo;
    protected Double precioBase;
    protected int copiasLicenciadas;

    public abstract Double calcularPrecio();

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(Double precioBase) {
        this.precioBase = precioBase;
    }

    public int getCopiasLicenciadas() {
        return copiasLicenciadas;
    }

    public void setCopiasLicenciadas(int copiasLicenciadas) {
        this.copiasLicenciadas = copiasLicenciadas;
    }
}
