package org.example;

import java.util.ArrayList;
import java.util.List;

public class Compra {
    private String nombreCliente;
    private Double total;

    private Libreria libreria;

    private List<Linea> lineas = new ArrayList<>();

    public Linea agregarLinea(String titulo, int cantidad) throws LibroException {

        Libro libro = libreria.buscarLibro(titulo);

        if (libro == null){
            throw new LibroException("Libro no existe");
        }

        if (cantidad > libro.getCopiasLicenciadas()){
            throw new LibroException("Cantidad Libro no existe");
        }

        //Calcular precio
        Double subTotal = libro.calcularPrecio() * cantidad;

        //Actualizar cantidad
        libro.setCopiasLicenciadas(libro.getCopiasLicenciadas() - cantidad);

        //Crear Linea
        Linea nuevaLinea = new  Linea(
                cantidad,
                subTotal,
                libro
        );

        //Agregar Linea
        this.lineas.add(nuevaLinea);

        this.totalizarCompra();

        return nuevaLinea;
    }

    public void removerLinea(String titulo){

        for(Linea linea : lineas){

            Libro libro = linea.getLibro();

            // buscar en lineas el libro
            if(libro.getTitulo().equals(titulo)){

                // Actualizar Copias licenciadas
                libro.setCopiasLicenciadas(
                        libro.getCopiasLicenciadas() + linea.getCantidad()
                );

                //Remover Linea de la lista
                lineas.remove(linea);

                this.totalizarCompra();
            }
        }

    }

    public Double totalizarCompra(){

        Double total = 0.0;

        for (Linea linea : lineas){
            total += linea.getSubTotal();
        }

        total = total*1.19;

        this.total = total;

        return total;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Libreria getLibreria() {
        return libreria;
    }

    public void setLibreria(Libreria libreria) {
        this.libreria = libreria;
    }

    public List<Linea> getLineas() {
        return lineas;
    }

    public void setLineas(List<Linea> lineas) {
        this.lineas = lineas;
    }
}
