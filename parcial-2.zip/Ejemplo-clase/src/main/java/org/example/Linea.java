package org.example;

public class Linea {
    private int cantidad;
    private Double subTotal;

    private Libro libro;

    public Linea(int cantidad, Double subTotal, Libro libro) {
        this.cantidad = cantidad;
        this.subTotal = subTotal;
        this.libro = libro;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(Double subTotal) {
        this.subTotal = subTotal;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }
}
