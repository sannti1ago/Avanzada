package org.example;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Libreria {

    private List<Compra> compras = new ArrayList<>();
    private List<Libro> catalogo = new ArrayList<>();

    public static void main(String[] args) {

    }

    public Libro buscarLibro(String titulo){

        for (Libro libro : catalogo){

            if (libro.getTitulo().equals(titulo)){
                return libro;
            }
        }
        return null;
    }

    public List<Compra> comprasSuperanTope(Double tope){

        List<Compra> superanTope = new ArrayList<>();

        for(Compra compra : compras){

            if (compra.totalizarCompra() > tope){
                superanTope.add(compra);
            }
        }

        return superanTope;
    }

    public Double totalizarValorLibros(){

        double total = 0.0;

        for(Libro libro : catalogo){

            total += libro.getCopiasLicenciadas()*libro.calcularPrecio();
        }

        return total;
    }

    public void generarReporteLibrosDigitales(){

        List<Libro> librosDigitales = new ArrayList<>();

        for (Libro libro : catalogo){

            if (libro instanceof LibroDigital){
                librosDigitales.add(libro);
            }
        }

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("librosDigitales.dat"));

            oos.writeObject(librosDigitales);

        } catch (IOException e) {
            System.out.println("Error al crear o escribir archivo");
        }
    }

    public List<Compra> getCompras() {
        return compras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }
}
